import { describe, expect, it } from 'vitest';
import { parseMeasure, displayMeasure, preferredUnit } from '../src/units';
import { createProject } from '../src/model';
describe('ruler units', () => {
 it('converts ruler centimetres to engineering millimetres', () => { expect(parseMeasure('12.5','cm')).toBe(125); expect(parseMeasure('١٢٫٥','cm')).toBe(125); expect(parseMeasure('۱۲,۵','cm')).toBe(125); });
 it('switches display without changing stored dimensions', () => { const p=createProject(); p.measures[0].value=700; expect(displayMeasure(p.measures[0].value,'cm')).toBe('70'); expect(parseMeasure(displayMeasure(125,'cm'),'cm')).toBe(125); expect(p.measures[0].value).toBe(700); expect(displayMeasure(25.4,'in')).toBe('1'); });
 it('rejects empty and malformed input', () => { for(const text of ['', ' ', '1,2,3', '-2', '1e4', 'abc']) expect(parseMeasure(text,'cm')).toBeNaN(); });
 it('defaults new installations to centimetres without browser storage', () => { expect(preferredUnit()).toBe('cm'); });
});
