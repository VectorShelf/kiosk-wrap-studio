import { it, expect } from 'vitest';
import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { Illustration } from '../src/Illustration';
import { initialMeasures, createProject } from '../src/model';
import { validPolygon, inside } from '../src/polygons';
import { validate } from '../src/geometry';
it('renders an Arabic labeled SVG for every measurement', () => { for (const m of initialMeasures()) {
    const html = renderToStaticMarkup(<Illustration measure={m}/>);
    expect(html).toContain('<svg');
    expect(html).toContain(m.code);
    expect(html).not.toContain('NaN');
} });
it('checks self intersection and point containment', () => { expect(validPolygon([[0, 0], [100, 100], [100, 0], [0, 100]])).toBe(false); expect(validPolygon([[0, 0], [100, 0], [100, 100], [0, 100]])).toBe(true); expect(inside([20, 20], [[0, 0], [100, 0], [100, 100], [0, 100]])).toBe(true); });
it('rejects a curved length shorter than the vertical projection', () => { const p = createProject(); p.measures = p.measures.map(m => ({ ...m, value: m.code === 'CL' ? 90 : m.code === 'CH' ? 100 : null })); expect(validate(p).some(i => i.message.includes('أقل من ارتفاعه'))).toBe(true); });
