import { describe, it, expect } from 'vitest';
import { createScriptLink, readScriptLink, scriptHash, isLocalAddress } from '../src/sharing';
import { createProject } from '../src/model';
import { generateJsx } from '../src/export';

const script = '#target illustrator\n// جهاز الجمعية — اختبار مشاركة\nalert("مرحبا");';
describe('portable script links', () => {
    it('round-trips the exact JSX and Arabic metadata without server storage', async () => {
        const link = await createScriptLink(script, 'تغليف الجمعية', 'Draft', 'https://example.github.io/kiosk-wrap-studio/?old=1#old');
        expect(link).toMatch(/^https:\/\/example.github.io\/kiosk-wrap-studio\/#jsx=[A-Za-z0-9_-]+$/);
        const payload = await readScriptLink(new URL(link).hash);
        expect(payload.script).toBe(script);
        expect(payload.projectName).toBe('تغليف الجمعية');
        expect(payload.sha256).toBe(await scriptHash(script));
        expect(payload.status).toBe('Draft');
    });
    it('keeps a fixed snapshot even when a newer script is shared', async () => {
        const first = await createScriptLink(script, 'project', 'Draft', 'https://example.github.io/studio/');
        const second = await createScriptLink(script + '\n// revised', 'project', 'Draft', 'https://example.github.io/studio/');
        expect((await readScriptLink(new URL(first).hash)).script).toBe(script);
        expect((await readScriptLink(new URL(second).hash)).script).toContain('revised');
    });
    it('fits a real generated template within the link budget', async () => {
        const p = createProject('اختبار برمجي للمشاركة — أبعاد افتراضية');
        p.measures[0].value = 700;
        p.measures[1].value = 1850;
        const jsx = generateJsx(p, ['front', 'reference', 'sheet']);
        const link = await createScriptLink(jsx, p.name, p.status, 'https://example.github.io/kiosk-wrap-studio/');
        expect(link.length).toBeLessThan(12000);
        expect((await readScriptLink(new URL(link).hash)).script).toBe(jsx);
    });
    it('rejects truncated and malformed links', async () => {
        await expect(readScriptLink('#jsx=not-valid')).rejects.toThrow();
        await expect(readScriptLink('#jsx=<script>')).rejects.toThrow();
        await expect(readScriptLink('#other=abc')).rejects.toThrow();
    });
    it('rejects a mismatched integrity fingerprint', async () => {
        const snapshot = { version: 1, projectName: 'test', status: 'Draft', createdAt: new Date().toISOString(), script, sha256: '0'.repeat(64) };
        const stream = new Blob([JSON.stringify(snapshot)]).stream().pipeThrough(new CompressionStream('gzip'));
        const bytes = new Uint8Array(await new Response(stream).arrayBuffer());
        const encoded = btoa(String.fromCharCode(...bytes)).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
        await expect(readScriptLink('#jsx=' + encoded)).rejects.toThrow('بصمة');
    });
    it('caps decompressed size before parsing untrusted JSON', async () => {
        const stream = new Blob(['x'.repeat(1024 * 1024 + 1)]).stream().pipeThrough(new CompressionStream('gzip'));
        const bytes = new Uint8Array(await new Response(stream).arrayBuffer());
        const encoded = btoa(String.fromCharCode(...bytes)).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
        await expect(readScriptLink('#jsx=' + encoded)).rejects.toThrow('أكبر من المسموح');
    });
    it('identifies local-only URLs and preserves project path', async () => {
        expect(isLocalAddress('http://127.0.0.1:5173/')).toBe(true);
        expect(isLocalAddress('http://localhost:5173/')).toBe(true);
        expect(isLocalAddress('https://example.github.io/studio/')).toBe(false);
        const link = await createScriptLink(script, 'test', 'Draft', 'https://example.github.io/studio/');
        expect(new URL(link).pathname).toBe('/studio/');
    });
});
