import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';
// Relative asset URLs support both github.io/<repository>/ and a custom domain.
export default defineConfig({ base: './', plugins: [react(), tailwindcss()] });
