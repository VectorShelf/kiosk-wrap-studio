#!/bin/zsh
cd "${0:A:h}"
if ! command -v node >/dev/null 2>&1; then
  bundled_node="$HOME/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin"
  if [[ -x "$bundled_node/node" ]]; then
    export PATH="$bundled_node:$PATH"
  else
    print 'يرجى تثبيت Node.js 22 أو أحدث ثم تشغيل الملف مجددًا.'
    exit 1
  fi
fi
if [[ ! -f node_modules/vite/bin/vite.js ]]; then
  print 'نفذ npm install مرة واحدة لإعداد الاعتماديات.'
  exit 1
fi
print 'Kiosk Wrap Studio: http://127.0.0.1:5173'
exec node node_modules/vite/bin/vite.js --host 127.0.0.1
