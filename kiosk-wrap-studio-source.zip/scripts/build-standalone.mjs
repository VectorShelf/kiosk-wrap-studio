import { build } from 'vite';
import fs from 'node:fs/promises';
import path from 'node:path';
import { execFileSync } from 'node:child_process';

// A self-contained HTML release can be uploaded through GitHub's web interface
// without storing credentials or granting a connector additional repository access.
const root = process.cwd();
const scratch = path.join(root, 'tmp/standalone-build');
const output = path.join(root, 'deployment');
await fs.mkdir(output, { recursive: true });
await fs.mkdir(path.join(root, 'tmp/reference-images'), { recursive: true });
const images = {};
for (const name of ['device', 'guide', 'lower', 'front-detail', 'components', 'hand-1', 'hand-2', 'hand-3']) {
    const source = path.join(root, `public/references/${name}.png`);
    let bytes;
    let mime = 'image/png';
    if (process.platform === 'darwin') {
        const target = path.join(root, `tmp/reference-images/${name}.jpg`);
        // Web delivery transcoding only; original full-resolution references stay in source.
        execFileSync('/usr/bin/sips', ['-Z', '1400', '-s', 'format', 'jpeg', '-s', 'formatOptions', '75', source, '--out', target], { stdio: 'ignore' });
        bytes = await fs.readFile(target); mime = 'image/jpeg';
    } else bytes = await fs.readFile(source);
    images[name] = `data:${mime};base64,${bytes.toString('base64')}`;
}
await build({
    configFile: path.join(root, 'vite.config.ts'),
    plugins: [{
        name: 'inline-reference-images',
        transform(_code, id) {
            if (id.replaceAll('\\', '/').endsWith('/src/references.ts')) return {
                code: `const images=${JSON.stringify(images)};export function referenceAsset(name){return images[name]||'';}`,
                map: null,
            };
        },
    }],
    build: {
        outDir: scratch, emptyOutDir: true, copyPublicDir: false,
        rollupOptions: { output: { inlineDynamicImports: true, entryFileNames: 'assets/app.js', assetFileNames: 'assets/[name][extname]' } },
    },
});
let html = await fs.readFile(path.join(scratch, 'index.html'), 'utf8');
const js = await fs.readFile(path.join(scratch, 'assets/app.js'), 'utf8');
const assets = await fs.readdir(path.join(scratch, 'assets'));
const css = (await Promise.all(assets.filter(n => n.endsWith('.css')).map(n => fs.readFile(path.join(scratch, 'assets', n), 'utf8')))).join('\n');
// Keep JavaScript in its own file. Rewriting HTML after injecting a large bundle
// can accidentally match HTML literals inside dependencies (e.g. DOMPurify).
html = html.replace(/<link[^>]*rel="stylesheet"[^>]*>/g, '');
html = html.replace('</head>', () => `<style>${css}</style></head>`);
html = html.replace(/<script[^>]*src="[^"]+"[^>]*><\/script>/, '<script type="module" src="./app.js"></script>');
await fs.writeFile(path.join(output, 'app.js'), js);
await fs.writeFile(path.join(output, 'index.html'), html);
await fs.writeFile(path.join(output, '.nojekyll'), '');
execFileSync(process.execPath, ['--check', path.join(output, 'app.js')], { stdio: 'inherit' });
console.log(`Static release: ${path.join(output, 'index.html')} + app.js (${Buffer.byteLength(html) + Buffer.byteLength(js)} bytes)`);
