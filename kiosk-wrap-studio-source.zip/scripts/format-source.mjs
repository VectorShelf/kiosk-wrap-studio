import fs from 'node:fs';
import ts from 'typescript';
const printer=ts.createPrinter({newLine:ts.NewLineKind.LineFeed});
for(const directory of ['src','tests']){
  for(const name of fs.readdirSync(directory).filter(n=>/\.tsx?$/.test(n))){
    const path=`${directory}/${name}`;
    const source=ts.createSourceFile(path,fs.readFileSync(path,'utf8'),ts.ScriptTarget.Latest,true,name.endsWith('.tsx')?ts.ScriptKind.TSX:ts.ScriptKind.TS);
    fs.writeFileSync(path,printer.printFile(source));
  }
}
