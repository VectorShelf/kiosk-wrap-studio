export function referenceAsset(name: string): string {
    return `${import.meta.env.BASE_URL}references/${name}.png`;
}
