import { Measure } from './model';
export function Illustration({ measure }: {
    measure: Measure;
}) { const c = measure.code; const color = measure.group === 'الشاشة' ? '#54baf7' : measure.group === 'الكاميرا' ? '#f7ac61' : measure.group === 'الطابعة' ? '#f37a90' : measure.group === 'NFC' ? '#e9c75d' : measure.group === 'الماسح' ? '#d595f5' : measure.group === 'الانحناء' ? '#b692fa' : '#2dd4bf'; const component = /[24567]$/.test(c); const boxes: Record<string, number[]> = { '2': [144, 43, 63, 17], '3': [62, 100, 226, 377], '4': [73, 528, 73, 71], '5': [176, 550, 45, 44], '6': [252, 552, 36, 36], '7': [57, 513, 244, 103] }; const b = (['BW', 'BH', 'BX', 'BY'].includes(c) ? [54, 91, 242, 395] : ['PW', 'PH', 'PX', 'PY'].includes(c) ? [78, 532, 59, 4] : boxes[c.slice(-1)]) ?? [25, 20, 300, 820]; let [x, y, w, h] = b; let vertical = /^[HY]/.test(c) || ['BH', 'BY', 'PH', 'PY'].includes(c) || ['M3', 'M4', 'CS', 'CE', 'CL', 'CH'].includes(c); if (c === 'W8') {
    x = 16;
    y = 839;
    w = 320;
} if (c === 'H8') {
    x = 18;
    y = 640;
    h = 180;
} if (c === 'M1') {
    x = 25;
    y = 275;
    w = 37;
} if (c === 'M2') {
    x = 288;
    y = 275;
    w = 37;
} if (c === 'M3') {
    x = 45;
    y = 20;
    h = 80;
} if (c === 'M4') {
    x = 45;
    y = 477;
    h = 36;
} if (c === 'H9') {
    x = 16;
    y = 815;
    h = 40;
} if (c.startsWith('X') || c === 'BX' || c === 'PX') {
    const origin = c === 'PX' ? 73 : ['X4', 'X5', 'X6'].includes(c) ? 57 : 25;
    w = Math.max(4, x - origin);
    x = origin;
} if (c.startsWith('Y') || c === 'BY' || c === 'PY') {
    const origin = c === 'PY' ? 528 : ['Y4', 'Y5', 'Y6'].includes(c) ? 513 : 20;
    h = Math.max(4, y - origin);
    y = origin;
} const side = measure.view === 'side'; return <svg className="illustration" viewBox={side ? '0 0 420 900' : '-50 -20 460 930'} role="img" aria-label={`رسم إرشادي ${measure.name}`}><defs><linearGradient id="shell" x1="0" x2="1"><stop stopColor="#d3dadb"/><stop offset=".45" stopColor="#fbfcfa"/><stop offset="1" stopColor="#c3cbcb"/></linearGradient><linearGradient id="glass" x2="1" y2="1"><stop stopColor="#263944"/><stop offset="1" stopColor="#0d1720"/></linearGradient><marker id="arrow" viewBox="0 0 10 10" refX="5" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse"><path d="M 0 0 L 10 5 L 0 10 z" fill={color}/></marker><pattern id="dots" width="20" height="20" patternUnits="userSpaceOnUse"><circle cx="1" cy="1" r=".7" fill="#b3c6ca" opacity=".25"/></pattern></defs><rect x="-50" y="-20" width="460" height="930" fill="url(#dots)"/>{side ? <><path d="M145 20 L220 20 L237 555 Q238 580 263 640 L270 820 L300 840 L100 840 L105 815 L185 805 L180 665 Q120 575 119 555 Z" fill="url(#shell)" stroke="#8b9e9e"/><path d="M220 552 Q210 598 250 653" fill="none" stroke={color} strokeWidth="3" strokeDasharray="8 5"/>{c.startsWith('D') ? <path d={c === 'D1' ? 'M145 5H220' : c === 'D2' ? 'M180 665H270' : 'M100 865H300'} fill="none" stroke={color} markerStart="url(#arrow)" markerEnd="url(#arrow)"/> : <path d="M90 20 V840" stroke={color} markerStart="url(#arrow)" markerEnd="url(#arrow)"/>}<text x="50" y="430" fill={color} fontSize="22">{c}</text></> : <><ellipse cx="175" cy="863" rx="161" ry="12" fill="#111e23" opacity=".14"/><path d="M49 20 H301 Q325 20 325 46 V627 Q325 651 308 704 L294 816 L335 840 Q341 852 326 855 H23 Q9 855 16 840 L52 815 L37 710 Q25 656 25 628 V46 Q25 20 49 20Z" fill="url(#shell)" stroke="#c1c9c9"/><rect x="140" y="40" width="72" height="23" rx="11" fill="#aeb7b7"/><rect x="144" y="43" width="63" height="17" rx="8" fill="#111e25"/>{[153, 165, 180, 195].map(a => <circle key={a} cx={a} cy="51" r="3" fill="#526568"/>)}<rect x="54" y="91" width="242" height="395" rx="2" fill="#080d11"/><rect x="62" y="100" width="226" height="377" fill="url(#glass)"/><path d="M62 100 H288 L62 390Z" fill="white" opacity=".035"/><rect x="57" y="513" width="244" height="103" rx="5" fill="#222a2e"/><rect x="73" y="528" width="73" height="71" rx="2" fill="#0d1418" stroke="#596368"/><path d="M78 535 H137" stroke="#718186" strokeWidth="3"/><rect x="176" y="550" width="45" height="44" rx="3" fill="#10191d"/><text x="198" y="572" fill="#cbd5d7" textAnchor="middle" fontSize="17">◉</text><text x="198" y="586" fill="#cbd5d7" textAnchor="middle" fontSize="8">NFC</text><rect x="252" y="552" width="36" height="36" fill="#0e171d"/><path d="M256 556 H284 V584 H256Z" fill="#d7dfde"/><circle cx="270" cy="570" r="3" fill="#667b82"/><path d="M27 634 Q176 648 324 634 M52 815 H294" fill="none" stroke="#b6c3c3"/>{component && <rect x={b[0] - 5} y={b[1] - 5} width={b[2] + 10} height={b[3] + 10} rx="5" fill={color} opacity=".12" stroke={color} strokeDasharray="5 4"/>}<g stroke={color} strokeWidth="1.7" fill="none">{vertical ? <><path d={`M${x - 13} ${y} H${x + w} M${x - 13} ${y + h} H${x + w}`} opacity=".5"/><path d={`M${x - 18} ${y} V${y + h}`} markerStart="url(#arrow)" markerEnd="url(#arrow)"/></> : <><path d={`M${x} ${y - 12} V${y + 10} M${x + w} ${y - 12} V${y + 10}`} opacity=".5"/><path d={`M${x} ${y - 16} H${x + w}`} markerStart="url(#arrow)" markerEnd="url(#arrow)"/></>}</g><text x={vertical ? x - 28 : x + w / 2} y={vertical ? y + h / 2 : y - 29} fill={color} fontWeight="700" fontSize="23" textAnchor={vertical ? 'end' : 'middle'}>{c}</text></>}<text x="175" y="892" fill="#8fa4aa" fontSize="12" textAnchor="middle">رسم إرشادي فقط • لا يمثل مقياسًا حقيقيًا</text></svg>; }
