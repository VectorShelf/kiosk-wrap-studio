import { z } from 'zod';
export type Measure = {
    code: string;
    name: string;
    group: string;
    view: string;
    description: string;
    value: number | null;
    source: 'measured' | 'derived' | 'estimated';
    notes: string;
    photo?: string;
    history?: number[];
};
const groups: Record<string, string[]> = {
    'الهيكل الخارجي': ['W1|العرض الكلي', 'H1|الارتفاع الكلي', 'D1|العمق العلوي', 'D2|عمق الجزء الأوسط', 'D3|عمق القاعدة', 'W8|عرض القاعدة', 'H8|ارتفاع الجزء السفلي', 'H9|ارتفاع القاعدة', 'W9|عرض الخلف', 'H10|ارتفاع الخلف'],
    'الشاشة': ['W3|عرض فتحة الشاشة', 'H3|ارتفاع فتحة الشاشة', 'M1|الهامش الأيسر', 'M2|الهامش الأيمن', 'M3|المسافة من أعلى الجهاز إلى الشاشة', 'M4|الفاصل بين الشاشة واللوحة', 'BW|عرض الإطار الأسود', 'BH|ارتفاع الإطار الأسود', 'BX|موقع الإطار الأفقي', 'BY|موقع الإطار الرأسي'],
    'الكاميرا': ['W2|عرض الكاميرا', 'H2|ارتفاع الكاميرا', 'X2|موقع الكاميرا الأفقي', 'Y2|موقع الكاميرا الرأسي', 'R2|نصف قطر الكاميرا'],
    'لوحة المكونات': ['W7|عرض لوحة المكونات', 'H7|ارتفاع لوحة المكونات', 'X7|موقع اللوحة الأفقي', 'Y7|موقع اللوحة الرأسي', 'R7|نصف قطر اللوحة'],
    'الطابعة': ['W4|عرض الطابعة', 'H4|ارتفاع الطابعة', 'X4|موقع الطابعة داخل اللوحة X', 'Y4|موقع الطابعة داخل اللوحة Y', 'PW|عرض فتحة الورق', 'PH|ارتفاع فتحة الورق', 'PX|موقع فتحة الورق داخل الطابعة X', 'PY|موقع فتحة الورق داخل الطابعة Y', 'SERVICE|مسافة صيانة الطابعة'],
    'NFC': ['W5|عرض NFC', 'H5|ارتفاع NFC', 'X5|موقع NFC داخل اللوحة X', 'Y5|موقع NFC داخل اللوحة Y'],
    'الماسح': ['W6|عرض الماسح', 'H6|ارتفاع الماسح', 'X6|موقع الماسح داخل اللوحة X', 'Y6|موقع الماسح داخل اللوحة Y'],
    'الانحناء': ['CS|بداية الانحناء Y', 'CE|نهاية الانحناء Y', 'CH|الارتفاع الرأسي للانحناء', 'CO|إزاحة الانحناء', 'CL|طول السطح الفعلي', 'R1|نصف قطر تقريبي للانحناء'],
    'الجوانب والحواف': ['SY1|ارتفاع تغير الشكل الأول', 'SY2|ارتفاع تغير الشكل الثاني', 'RO|نصف قطر الهيكل الخارجي', 'EDGE|سماحية الالتفاف', 'OVERLAP|تراكب القطع']
};
export const initialMeasures = (): Measure[] => Object.entries(groups).flatMap(([group, rows]) => rows.map(row => { const [code, name] = row.split('|'); return { code, name, group, view: group === 'الجوانب والحواف' || group === 'الانحناء' || code.startsWith('D') ? 'side' : code === 'W9' || code === 'H10' ? 'back' : 'front', description: `قس ${name} باستخدام شريط القياس. المرجع أعلى اليسار؛ مواقع المكونات محلية داخل لوحة المكونات.`, value: null, source: 'measured', notes: '' }; }));
export const zones = ['Wrap', 'Cutout', 'No Print', 'Protected', 'Reference Only', 'Overlap'] as const;
export type Shape = {
    id: string;
    name: string;
    x: number;
    y: number;
    w: number;
    h: number;
    r: number;
    rotation: number;
    shape: 'rectangle' | 'rounded' | 'circle' | 'ellipse' | 'polygon' | 'path';
    points?: number[][];
    path?: string;
    parent?: string;
    approved?: boolean;
    overlap?: number;
    safe?: number;
    zone: string;
};
export type Project = {
    id: string;
    name: string;
    device: string;
    type: string;
    scope: string;
    unit: 'mm' | 'cm' | 'in';
    updated: string;
    measures: Measure[];
    tolerance: number;
    safety: number;
    photos: string[];
    zones: Record<string, string>;
    custom: Shape[];
    mode: string;
    pieces: Shape[];
    checks: boolean[];
    sidePoints: number[][];
    curvePoints: number[][];
    status: string;
    profiles: Record<string, number[][]>;
    overrides: Record<string, Partial<Shape>>;
};
export const createProject = (name = 'مشروع جهاز الجمعية'): Project => ({ id: crypto.randomUUID(), name, device: 'جهاز الخدمة الذاتية', type: 'Kiosk', scope: 'أمامي', unit: 'mm', updated: new Date().toISOString(), measures: initialMeasures(), tolerance: 1, safety: 3, photos: [], zones: { screen: 'Cutout', camera: 'Cutout', panel: 'Reference Only', printer: 'Protected', nfc: 'Protected', scanner: 'Cutout', paper: 'Cutout' }, custom: [], mode: 'single', pieces: [], checks: [false, false, false, false], sidePoints: [], curvePoints: [], status: 'Draft', profiles: {}, overrides: {} });
const measureSchema = z.object({ code: z.string().min(1), name: z.string(), group: z.string(), view: z.string(), description: z.string(), value: z.number().finite().nonnegative().nullable(), source: z.enum(['measured', 'derived', 'estimated']), notes: z.string(), photo: z.string().optional(), history: z.array(z.number().finite().nonnegative()).optional() });
const shapeSchema = z.object({ id: z.string(), name: z.string(), x: z.number().finite(), y: z.number().finite(), w: z.number().positive(), h: z.number().positive(), r: z.number().nonnegative(), rotation: z.number().finite(), shape: z.enum(['rectangle', 'rounded', 'circle', 'ellipse', 'polygon', 'path']), points: z.array(z.array(z.number().finite())).optional(), path: z.string().optional(), parent: z.string().optional(), approved:z.boolean().optional(), overlap:z.number().nonnegative().optional(), safe:z.number().nonnegative().optional(), zone: z.string() });
export const projectSchema = z.object({ id: z.string(), name: z.string().min(1), device: z.string(), type: z.string(), scope: z.string(), unit: z.enum(['mm', 'cm', 'in']), updated: z.string(), measures: z.array(measureSchema), tolerance: z.number().nonnegative(), safety: z.number().nonnegative(), photos: z.array(z.string()), zones: z.record(z.string()), custom: z.array(shapeSchema), mode: z.string(), pieces: z.array(shapeSchema), checks: z.array(z.boolean()), sidePoints: z.array(z.array(z.number().finite())), curvePoints: z.array(z.array(z.number().finite())), status: z.string(), overrides: z.record(shapeSchema.partial()).default({}), profiles: z.record(z.array(z.tuple([z.number().finite().nonnegative(), z.number().finite().nonnegative()]))).default({}) }).superRefine((p, c) => { const allIds = [...p.custom.map(s => s.id)]; if (new Set(allIds).size !== allIds.length)
    c.addIssue({ code: 'custom', message: 'معرّفات العناصر مكررة' }); for (const s of p.custom) {
    const seen = new Set([s.id]);
    let parent = s.parent;
    while (parent) {
        if (seen.has(parent)) {
            c.addIssue({ code: 'custom', message: 'دورة في علاقات العناصر' });
            break;
        }
        seen.add(parent);
        parent = p.custom.find(a => a.id === parent)?.parent;
    }
} if (new Set(p.measures.map(m => m.code)).size !== p.measures.length)
    c.addIssue({ code: 'custom', message: 'رموز القياسات مكررة' }); });
export const val = (p: Project, c: string) => p.measures.find(m => m.code === c)?.value ?? null;
export const factor = (unit: string) => unit === 'cm' ? 10 : unit === 'in' ? 25.4 : 1;
