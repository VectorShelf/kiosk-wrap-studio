import { openDB } from 'idb';
import { Project, projectSchema } from './model';
const db = () => openDB('kiosk-wrap-studio', 1, { upgrade(d) { d.createObjectStore('projects', { keyPath: 'id' }); } });
export async function saveProject(p: Project) { await (await db()).put('projects', projectSchema.parse(p)); }
export async function listProjects(): Promise<Project[]> { return (await (await db()).getAll('projects')).map(p => projectSchema.parse(p) as Project).sort((a, b) => b.updated.localeCompare(a.updated)); }
