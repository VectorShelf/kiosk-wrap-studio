import React, { useEffect, useState } from 'react';
import { Link, Copy, Share2, Download, FileCode2, ArrowRight, CheckCircle2, AlertTriangle } from 'lucide-react';
import { createScriptLink, readScriptLink, ScriptSnapshot, isLocalAddress } from './sharing';
import { download } from './export';

export function ScriptShare({ getScript, projectName, status }: { getScript: () => string; projectName: string; status: string }) {
    const [link, setLink] = useState('');
    const [busy, setBusy] = useState(false);
    const [message, setMessage] = useState('');
    // A generated link deliberately keeps its exact snapshot when measurements later change.
    async function generate() {
        setBusy(true); setMessage(''); setLink('');
        try { setLink(await createScriptLink(getScript(), projectName, status, window.location.href)); }
        catch (error) { setMessage(error instanceof Error ? error.message : String(error)); }
        finally { setBusy(false); }
    }
    async function copy() {
        try { await navigator.clipboard.writeText(link); setMessage('تم نسخ الرابط. أرسله إلى الكمبيوتر ثم نزّل ملف JSX.'); }
        catch { setMessage('اضغط على حقل الرابط وحدده كاملًا لنسخه يدويًا.'); }
    }
    async function share() {
        try { await navigator.share({ title: 'Kiosk Wrap Studio — سكريبت Illustrator', url: link }); }
        catch (error) { if (!(error instanceof DOMException && error.name === 'AbortError')) setMessage('تعذرت المشاركة. استخدم نسخ الرابط.'); }
    }
    return <section className="script-sharing" aria-label="مشاركة سكريبت Illustrator">
        <h3><Link size={18}/> أرسل السكريبت من الجوال للكمبيوتر</h3>
        <p>أنشئ رابطًا يحمل نسخة ثابتة من السكريبت الحالي، ثم افتحه على الكمبيوتر لتنزيل ملف JSX.</p>
        <button type="button" className="primary" disabled={busy} onClick={generate}><Link size={17}/>{busy ? 'جارٍ إنشاء الرابط…' : 'إنشاء رابط السكريبت'}</button>
        {link && <>
            <label className="share-link-label">رابط السكريبت<input aria-label="رابط السكريبت" dir="ltr" readOnly value={link} onFocus={e => e.currentTarget.select()}/></label>
            <div className="share-actions"><button onClick={copy}><Copy size={16}/>نسخ الرابط</button>{typeof navigator.share === 'function' && !isLocalAddress(link) && <button onClick={share}><Share2 size={16}/>مشاركة الرابط</button>}</div>
            {isLocalAddress(link) && <div className="issue warning"><AlertTriangle size={16}/>هذا رابط معاينة محلي. أنشئ الرابط من الموقع المنشور على GitHub Pages ليعمل على جهاز آخر.</div>}
            <p className="share-note">من يملك الرابط يستطيع تنزيل هذه النسخة من السكريبت وقياساتها. لا يتضمن الرابط صورك أو قاعدة مشاريعك. عند تعديل القياسات أنشئ رابطًا جديدًا.</p>
        </>}
        {message && <p role="status" className="share-message">{message}</p>}
    </section>;
}

export function SharedScriptPage() {
    const [snapshot, setSnapshot] = useState<ScriptSnapshot | null>(null);
    const [error, setError] = useState('');
    const [message, setMessage] = useState('');
    useEffect(() => {
        let alive = true;
        readScriptLink(window.location.hash).then(data => { if (alive) setSnapshot(data); }).catch(e => { if (alive) setError(e.message); });
        return () => { alive = false; };
    }, []);
    return <div className="app dark shared-page"><main className="shared-card card">
        <div className="export-icon"><FileCode2 size={35}/></div>
        <div className="eyebrow">KIOSK WRAP STUDIO / SHARED SCRIPT</div>
        <h1>{error ? 'تعذر فتح السكريبت' : snapshot ? 'سكريبت Illustrator جاهز للتنزيل' : 'جارٍ قراءة السكريبت…'}</h1>
        {error && <div className="issue error" role="alert"><AlertTriangle size={18}/>{error}</div>}
        {snapshot && <>
            <h2>{snapshot.projectName}</h2>
            <p>نسخة أُنشئت في {new Date(snapshot.createdAt).toLocaleString('ar-SA')} • الحالة: <b>{snapshot.status}</b></p>
            <div className="issue success"><CheckCircle2 size={18}/>تم التحقق من بصمة الملف. هذه النسخة مستقلة عن المشاريع المحفوظة في هذا المتصفح.</div>
            <button className="primary download-shared" onClick={() => { download('kiosk-template.jsx', snapshot.script, 'application/javascript;charset=utf-8'); setMessage('تم طلب تنزيل kiosk-template.jsx. افتحه من داخل Illustrator كما هو موضح أدناه.'); }}><Download size={19}/>تنزيل سكريبت Illustrator (.jsx)</button>
            <p role="status">{message}</p>
            <h3>تشغيله على الكمبيوتر</h3>
            <ol><li>نزّل الملف على جهاز فيه Adobe Illustrator.</li><li>افتح Illustrator ثم <span dir="ltr">File → Scripts → Other Script</span>.</li><li>اختر <span dir="ltr">kiosk-template.jsx</span> لإنشاء القالب.</li><li>راجع المقاسات ونفّذ اختبار تطابق فعلي قبل الطباعة.</li></ol>
            <details><summary>معاينة نص السكريبت وبصمته</summary><p className="checksum" dir="ltr">SHA-256: {snapshot.sha256}</p><textarea aria-label="نص السكريبت المشترك" dir="ltr" readOnly value={snapshot.script}/><button onClick={async () => { try { await navigator.clipboard.writeText(snapshot.script); setMessage('تم نسخ نص السكريبت. احفظه بامتداد .jsx.'); } catch { setMessage('حدّد نص السكريبت وانسخه يدويًا.'); } }}><Copy size={16}/>نسخ نص السكريبت</button></details>
        </>}
        <a className="back-to-studio" href={window.location.pathname}><ArrowRight size={16}/>فتح الاستوديو</a>
    </main></div>;
}
