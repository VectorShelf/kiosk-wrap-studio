import { factor, type Project } from './model';
type Unit = Project['unit'];
export const unitLabels: Record<Unit, string> = { cm: 'CM — سنتيمتر', mm: 'MM — مليمتر', in: 'IN — بوصة' };
export function preferredUnit(): Unit {
    try { const unit = localStorage.getItem('kiosk-measure-unit'); if (unit === 'mm' || unit === 'cm' || unit === 'in') return unit; } catch { /* Storage may be disabled. */ }
    return 'cm';
}
export function rememberUnit(unit: Unit) { try { localStorage.setItem('kiosk-measure-unit', unit); } catch { /* Project persistence remains available. */ } }
export function displayMeasure(mm: number, unit: Unit): string { return String(Number((mm / factor(unit)).toPrecision(12))); }
export function parseMeasure(input: string, unit: Unit): number {
    const normalized = input.trim().replace(/[٠-٩۰-۹]/g, c => String(c.charCodeAt(0) - (c <= '٩' ? 0x660 : 0x6f0))).replace(/[٫,]/g, '.');
    if (!/^[+]?(?:\d+(?:\.\d*)?|\.\d+)$/.test(normalized)) return NaN;
    return Number((Number(normalized) * factor(unit)).toPrecision(12));
}
