import { Project, Shape, val } from './model';
import { geometry, globalShape, exportSvg, mmToPt, validate, productionReady } from './geometry';
import { parsePath } from './paths';
export const layers = ['00_INSTRUCTIONS', '01_DEVICE_REFERENCE', '02_ARTWORK', '03_WRAP_AREAS', '04_CUT_CONTOURS', '05_COMPONENT_CUTOUTS', '06_SAFE_ZONES', '07_DIMENSIONS', '08_GUIDES', '09_NOTES'];
export type Board = {
    id: string;
    name: string;
    w: number;
    h: number;
    reference?: boolean;
    points?: number[][];
    items: Shape[];
    pieces?: Shape[];
};
const bounds = (points: number[][]) => ({ w: Math.max(...points.map(a => a[0])), h: Math.max(...points.map(a => a[1])) });
export function boards(p: Project): Board[] { const w = val(p, 'W1'), h = val(p, 'H1'); if (!w || !h)
    return []; const all = geometry(p), global = all.filter(s=>!['back','left','right'].includes(s.parent??'')).map(s => globalShape(s, all)), front = p.profiles?.front ?? []; const b: Board[] = [{ id: 'front', name: front.length >= 3 ? '01 Front Wrap' : '01 Front Wrap - REFERENCE ONLY', ...(front.length >= 3 ? bounds(front) : { w, h }), reference: front.length < 3, points: front, items: global, pieces: p.mode === 'single' ? [] : p.pieces }, { id: 'reference', name: '02 Device Reference', w, h, reference: true, items: global }]; if (val(p, 'W7') && val(p, 'H7')) {
    const panel = all.find(s => s.id === 'panel');
    const items = all.filter(s => ['printer', 'nfc', 'scanner', 'paper'].includes(s.id)).map(s => { const g = globalShape(s, all); return { ...g, x: g.x - (panel?.x ?? 0), y: g.y - (panel?.y ?? 0) }; });
    b.push({ id: 'panel', name: '03 Components Panel', w: val(p, 'W7')!, h: val(p, 'H7')!, items });
} if (val(p, 'H8')) {
    const points = p.profiles?.lower ?? [];
    const valid = points.length >= 3 && p.checks[1] && Boolean(val(p, 'CL'));
    b.push({ id: 'lower', name: valid ? '04 Lower Section - traced' : '04 Lower Section - REFERENCE ONLY', ...(valid ? bounds(points) : { w, h: val(p, 'H8')! }), points: valid ? points : [], reference: !valid, items: [] });
} for (const id of ['right', 'left']) {
    const points = p.profiles?.[id] ?? (id === 'right' ? p.sidePoints : []);
    if (points.length >= 3)
        b.push({ id, name: id === 'right' ? '05 Right Side' : '06 Left Side', ...bounds(points), points, items: p.custom.filter(s=>s.parent===id) });
} if (val(p, 'W9') && val(p, 'H10')) {
    const points = p.profiles?.back ?? [];
    b.push({ id: 'back', name: points.length >= 3 ? '07 Back' : '07 Back - REFERENCE ONLY', w: val(p, 'W9')!, h: val(p, 'H10')!, reference: points.length < 3, points, items: p.custom.filter(s => s.parent === 'back') });
} if(p.mode!=='single')for(const [i,piece] of p.pieces.entries()){
 const overlap=piece.overlap??0;const children=global.filter(s=>s.x>=piece.x&&s.y>=piece.y&&s.x+s.w<=piece.x+piece.w&&s.y+s.h<=piece.y+piece.h).map(s=>({...s,x:s.x-piece.x+overlap,y:s.y-piece.y+overlap}));
 b.push({id:'piece-'+piece.id,name:`Piece ${i+1} - ${piece.name}${piece.approved?'':' - DRAFT'}`,w:piece.w+2*overlap,h:piece.h+2*overlap,points:piece.shape==='polygon'?piece.points:[[0,0],[piece.w+2*overlap,0],[piece.w+2*overlap,piece.h+2*overlap],[0,piece.h+2*overlap]],items:children});
 }
 b.push({ id: 'sheet', name: '08 Measurement Sheet', w: 420, h: Math.max(297, p.measures.length * 6 + 40), items: [] }); return b; }
export function layoutBoards(bs: Board[]) { const max = 16000, gap = 100; let x = 0, y = 0, row = 0; return bs.map(b => { const w = mmToPt(b.w), h = mmToPt(b.h); if (w > max || h > max)
    throw Error('يتجاوز القالب حدود اللوحة القياسية. قسّمه أو استخدم Large Canvas؛ لم يتغير المقياس.'); if (x + w > max) {
    x = 0;
    y += row + gap;
    row = 0;
} if (y + h > max)
    throw Error('تجاوز مجموع اللوحات مساحة الرسم؛ صدّر عددًا أقل من اللوحات.'); const placed = { ...b, ox: x - 8000, oy: 8000 - y }; x += w + gap; row = Math.max(row, h); return placed; }); }
export function generateJsx(p: Project, selected: string[]) {
    const bs = boards(p).filter(b => selected.includes(b.id));
    if (!bs.length)
        throw Error('اختر لوحة مكتملة واحدة على الأقل');
    if (validate(p).some(i => i.level === 'error'))
        throw Error('صحح التعارضات الهندسية قبل تصدير JSX');
    const data = layoutBoards(bs).map(b => ({ ...b, items: b.items.map(s => ({ ...s, beziers: s.shape === 'path' ? parsePath(s.path ?? '') : undefined })) }));
    const metadata = { status: p.status, productionReady: productionReady(p), exported: new Date().toISOString(), safety: p.safety, mode: p.mode };
    return `#target illustrator
(function(){
var K=72/25.4, data=${JSON.stringify(data)}, meta=${JSON.stringify(metadata)}, measured=${JSON.stringify(p.measures.map(m => ({ code: m.code, name: m.name, value: m.value, source: m.source })))}, names=${JSON.stringify(layers)};
var doc=app.documents.add(DocumentColorSpace.CMYK,100,100),ls={};
for(var i=0;i<names.length;i++){var l=doc.layers.add();l.name=names[i];ls[names[i]]=l;}
function color(r,g,b){var c=new RGBColor();c.red=r;c.green=g;c.blue=b;return c;}
function style(q,layer){q.filled=false;q.stroked=true;q.strokeWidth=0.5;q.strokeColor=layer.name==='05_COMPONENT_CUTOUTS'?color(225,65,120):color(25,145,140);return q;}
function rect(layer,x,y,w,h,r){var q=r?layer.pathItems.roundedRectangle(y,x,w*K,h*K,r*K,r*K):layer.pathItems.rectangle(y,x,w*K,h*K);style(q,layer);if(Math.abs(q.width-w*K)>0.05||Math.abs(q.height-h*K)>0.05)throw Error('Dimension verification failed');return q;}
function text(layer,t,x,y){var f=layer.textFrames.add();f.contents=t;f.position=[x,y];f.textRange.characterAttributes.size=10;return f;}
function line(layer,pts,closed){var q=layer.pathItems.add();q.setEntirePath(pts);q.closed=closed;return style(q,layer);}
function polygon(layer,points,ox,oy){var pts=[];for(var j=0;j<points.length;j++)pts.push([ox+points[j][0]*K,oy-points[j][1]*K]);return line(layer,pts,true);}
function rp(s,p,ox,oy){var a=s.rotation*Math.PI/180,dx=p[0]-s.w/2,dy=p[1]-s.h/2;return [ox+(s.x+s.w/2+dx*Math.cos(a)-dy*Math.sin(a))*K,oy-(s.y+s.h/2+dx*Math.sin(a)+dy*Math.cos(a))*K];}
function dimension(label,x,y,w,ox,oy){var layer=ls['07_DIMENSIONS'],x1=ox+x*K,y1=oy-y*K,x2=x1+w*K;line(layer,[[x1,y1],[x2,y1]],false);line(layer,[[x1+5,y1+3],[x1,y1],[x1+5,y1-3]],false);line(layer,[[x2-5,y1+3],[x2,y1],[x2-5,y1-3]],false);text(layer,label,x1,y1+13);}
for(var bi=0;bi<data.length;bi++){var b=data[bi],ox=b.ox,oy=b.oy,ab=[ox,oy,ox+b.w*K,oy-b.h*K];if(bi===0)doc.artboards[0].artboardRect=ab;else doc.artboards.add(ab);doc.artboards[bi].name=b.name;
if(b.id==='sheet'){text(ls['09_NOTES'],meta.productionReady?'PRODUCTION READY':'DRAFT - TEST FIT REQUIRED',ox+10,oy-15);rect(ls['01_DEVICE_REFERENCE'],ox+300*K,oy-20*K,100,100,0);text(ls['09_NOTES'],'100 mm calibration square',ox+300*K,oy-15*K);for(var mi=0;mi<measured.length;mi++)text(ls['09_NOTES'],measured[mi].code+' '+measured[mi].name+' = '+(measured[mi].value===null?'MISSING':measured[mi].value+' mm')+' ['+measured[mi].source+']',ox+10,oy-35-mi*6*K);}
else{var outlineLayer=ls[b.reference?'01_DEVICE_REFERENCE':'04_CUT_CONTOURS'];if(b.points&&b.points.length>=3)polygon(outlineLayer,b.points,ox,oy);else rect(outlineLayer,ox,oy,b.w,b.h,0);
if(b.pieces)for(var wi=0;wi<b.pieces.length;wi++){var wp=b.pieces[wi];rect(ls['03_WRAP_AREAS'],ox+wp.x*K,oy-wp.y*K,wp.w,wp.h,wp.r);if(wp.overlap)rect(ls['03_WRAP_AREAS'],ox+(wp.x-wp.overlap)*K,oy-(wp.y-wp.overlap)*K,wp.w+2*wp.overlap,wp.h+2*wp.overlap,0);text(ls['09_NOTES'],'Piece '+(wi+1)+' '+wp.name,ox+wp.x*K,oy-wp.y*K-12);}
for(var si=0;si<b.items.length;si++){var s=b.items[si],layer=ls[b.reference?'01_DEVICE_REFERENCE':s.zone==='Cutout'?'05_COMPONENT_CUTOUTS':s.zone==='Wrap'||s.zone==='Overlap'?'03_WRAP_AREAS':'01_DEVICE_REFERENCE'];var q;
if(s.shape==='ellipse'||s.shape==='circle'){q=layer.pathItems.ellipse(oy-s.y*K,ox+s.x*K,s.w*K,(s.shape==='circle'?s.w:s.h)*K);style(q,layer);}
else if(s.shape==='polygon'){var ps=[];for(var pj=0;pj<s.points.length;pj++)ps.push(rp(s,s.points[pj],ox,oy));q=line(layer,ps,true);}
else if(s.shape==='path'){for(var sub=0;sub<s.beziers.length;sub++){var bez=s.beziers[sub];q=layer.pathItems.add();for(var ai=0;ai<bez.nodes.length;ai++){var an=bez.nodes[ai],pp=q.pathPoints.add();pp.anchor=rp(s,an.a,ox,oy);pp.leftDirection=rp(s,an.l,ox,oy);pp.rightDirection=rp(s,an.r,ox,oy);pp.pointType=PointType.CORNER;}q.closed=bez.closed;style(q,layer);q.name=s.id;}}
else q=rect(layer,ox+s.x*K,oy-s.y*K,s.w,s.h,s.r);
if(q){q.name=s.id;if(s.rotation&&s.shape!=='path'&&s.shape!=='polygon')q.rotate(-s.rotation);}if(s.zone==='Cutout'&&meta.safety>0)rect(ls['06_SAFE_ZONES'],ox+(s.x-meta.safety)*K,oy-(s.y-meta.safety)*K,s.w+2*meta.safety,s.h+2*meta.safety,0);
if(b.reference)dimension(s.id+' '+s.w+' x '+s.h+' mm',s.x,s.y-5,s.w,ox,oy);}
text(ls['00_INSTRUCTIONS'],b.name+' | 1:1 mm | '+meta.status,ox+10,oy-12);if(b.reference)text(ls['09_NOTES'],'REFERENCE ONLY - NO PRODUCTION CUT CONTOUR',ox+10,oy-28);}
}
text(ls['00_INSTRUCTIONS'],'Export '+meta.exported+' | verify NFC, maintenance access and physical fit.',data[0].ox+10,data[0].oy-44);
ls['01_DEVICE_REFERENCE'].locked=true;ls['07_DIMENSIONS'].locked=true;ls['08_GUIDES'].locked=true;doc.activeLayer=ls['02_ARTWORK'];alert('Template created at 1:1. Verify 100 mm test square and physical fit before production.');
})();`;
}
export const csv = (p: Project) => '\uFEFF' + [['Code', 'Name', 'Value (mm)', 'Source', 'Notes'], ...p.measures.map(m => [m.code, m.name, m.value ?? '', m.source, m.notes])].map(r => r.map(v => '"' + String(v).replace(/"/g, '""') + '"').join(',')).join('\r\n');
export const download = (name: string, data: Blob | string, type = 'text/plain') => { const url = URL.createObjectURL(data instanceof Blob ? data : new Blob([data], { type })); const a = document.createElement('a'); a.href = url; a.download = name; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 60000); };
export const readme = `Kiosk Wrap Studio
1. Illustrator: File > Scripts > Other Script, choose template.jsx.
2. Confirm mm units and 1:1 dimensions. Print the 100 mm calibration square at 100% (disable fit-to-page) and measure it.
3. Inspect cutouts, local component positions, safety margins and locked reference layers.
4. Use 02_ARTWORK for artwork. Cut lines are independent paths; assign the print provider's cut spot color manually.
5. Test fit on the real kiosk. Confirm NFC reading and maintenance access.
6. Front and lower surface contours require measured flat traces. Without a trace their artboards are REFERENCE ONLY. Each side needs its own measured polygon. Add rear doors/ports before approval.
7. Custom paths support M/L/H/V/C/S/Q/T/Z. Convert SVG arc A commands to cubic C first.
JSX has not been executed inside Adobe Illustrator by the app. PDF is an English reference measurement sheet, not a cutting template.
Script API reference: https://ai-scripting.docsforadobe.dev/jsobjref/PathItems/
`;
export async function pdf(p: Project) { const { jsPDF } = await import('jspdf'); const d = new jsPDF(); d.text('Kiosk Wrap Studio | REFERENCE ONLY', 14, 18); d.setFontSize(9); let y = 30; for (const m of p.measures) {
    if (y > 280) {
        d.addPage();
        y = 20;
    }
    d.text(`${m.code}: ${m.value ?? 'MISSING'} mm | ${m.source}`, 14, y);
    y += 5;
} return d.output('blob'); }
export async function zip(p: Project, ids: string[]) { const { default: JSZip } = await import('jszip'); const z = new JSZip(); z.file('template.jsx', generateJsx(p, ids)); z.file('front.svg', exportSvg(p)); z.file('project.json', JSON.stringify(p, null, 2)); z.file('measurements.csv', csv(p)); z.file('reference.pdf', await pdf(p)); z.file('README.txt', readme); z.file('manifest.json', JSON.stringify({ exportedAt: new Date().toISOString(), status: p.status, productionReady: productionReady(p), artboards: ids })); download('kiosk-wrap-' + new Date().toISOString().slice(0, 10) + '.zip', await z.generateAsync({ type: 'blob' })); }
