/** Normalize SVG M/L/H/V/C/S/Q/T/Z into editable cubic Bezier anchors.
 * Elliptical arcs require conversion to cubic curves in the source path. */
export type Anchor = {
    a: number[];
    l: number[];
    r: number[];
};
export function parsePath(d: string): {
    nodes: Anchor[];
    closed: boolean;
}[] { const tokens = d.match(/[a-zA-Z]|[-+]?(?:\d*\.\d+|\d+\.?\d*)(?:e[-+]?\d+)?/g) ?? []; let i = 0, cmd = '', x = 0, y = 0, sx = 0, sy = 0, lastControl: number[] | null = null, lastCmd = ''; const paths: {
    nodes: Anchor[];
    closed: boolean;
}[] = []; let nodes: Anchor[] = []; const add = (px: number, py: number) => { nodes.push({ a: [px, py], l: [px, py], r: [px, py] }); x = px; y = py; }; const n = () => { const v = Number(tokens[i++]); if (!Number.isFinite(v))
    throw Error('مسار SVG غير صالح'); return v; }; while (i < tokens.length) {
    if (/^[a-z]$/i.test(tokens[i]))
        cmd = tokens[i++];
    const upper = cmd.toUpperCase(), rel = cmd !== upper;
    const ox = rel ? x : 0, oy = rel ? y : 0;
    if (upper === 'Z') {
        if (nodes.length)
            paths.push({ nodes, closed: true });
        nodes = [];
        x = sx;
        y = sy;
        cmd = '';
        lastControl = null;
        continue;
    }
    if (!'MLHVCSQT'.includes(upper) || !cmd)
        throw Error('مسار SVG: استخدم M/L/H/V/C/S/Q/T/Z؛ حوّل A إلى منحنيات C قبل التصدير');
    if (upper === 'M') {
        if (nodes.length)
            paths.push({ nodes, closed: false });
        nodes = [];
        add(n() + ox, n() + oy);
        sx = x;
        sy = y;
        cmd = rel ? 'l' : 'L';
    }
    else if (upper === 'L')
        add(n() + ox, n() + oy);
    else if (upper === 'H')
        add(n() + ox, y);
    else if (upper === 'V')
        add(x, n() + oy);
    else {
        if (!nodes.length)
            throw Error('المسار يجب أن يبدأ بـ M');
        let c1: number[], c2: number[], end: number[];
        if (upper === 'C') {
            c1 = [n() + ox, n() + oy];
            c2 = [n() + ox, n() + oy];
            end = [n() + ox, n() + oy];
        }
        else if (upper === 'S') {
            c1 = ['C', 'S'].includes(lastCmd) && lastControl ? [2 * x - lastControl[0], 2 * y - lastControl[1]] : [x, y];
            c2 = [n() + ox, n() + oy];
            end = [n() + ox, n() + oy];
        }
        else {
            const q: number[] = upper === 'Q' ? [n() + ox, n() + oy] : ['Q', 'T'].includes(lastCmd) && lastControl ? [2 * x - lastControl[0], 2 * y - lastControl[1]] : [x, y];
            end = [n() + ox, n() + oy];
            c1 = [x + (q[0] - x) * 2 / 3, y + (q[1] - y) * 2 / 3];
            c2 = [end[0] + (q[0] - end[0]) * 2 / 3, end[1] + (q[1] - end[1]) * 2 / 3];
            lastControl = q;
        }
        nodes[nodes.length - 1].r = c1;
        add(end[0], end[1]);
        nodes[nodes.length - 1].l = c2;
        if (upper === 'C' || upper === 'S')
            lastControl = c2;
    }
    if (!['C', 'S', 'Q', 'T'].includes(upper))
        lastControl = null;
    lastCmd = upper;
    if (i > tokens.length)
        throw Error('مسار ناقص');
} if (nodes.length)
    paths.push({ nodes, closed: false }); return paths; }
