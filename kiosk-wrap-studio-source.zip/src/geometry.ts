import { validPolygon, inside } from './polygons';
import { parsePath } from './paths';
import { Project, Shape, val } from './model';
export const mmToPt = (n: number) => n * 72 / 25.4;
export const aiPoint = (x: number, y: number, ox = 0, oy = 0) => [ox + mmToPt(x), oy - mmToPt(y)];
export function geometry(p: Project): Shape[] { const out: Shape[] = []; const add = (id: string, name: string, wc: string, hc: string, xc: string, yc: string, rc?: string, parent?: string) => { if(parent&&!out.some(s=>s.id===parent))return;const a = [wc, hc, xc, yc].map(c => val(p, c)); if (a.some(n => n === null))
    return; const [w, h, x, y] = a as number[]; out.push({ id, name, x, y, w, h, r: rc ? val(p, rc) ?? 0 : 0, rotation: 0, shape: 'rounded', parent, zone: p.zones[id] ?? 'Reference Only' }); }; add('screen', 'الشاشة', 'W3', 'H3', 'M1', 'M3'); add('frame', 'إطار الشاشة', 'BW', 'BH', 'BX', 'BY'); add('camera', 'الكاميرا', 'W2', 'H2', 'X2', 'Y2', 'R2'); add('panel', 'لوحة المكونات', 'W7', 'H7', 'X7', 'Y7', 'R7'); add('printer', 'غطاء الطابعة', 'W4', 'H4', 'X4', 'Y4', undefined, 'panel'); add('nfc', 'قارئ NFC', 'W5', 'H5', 'X5', 'Y5', undefined, 'panel'); add('scanner', 'الماسح', 'W6', 'H6', 'X6', 'Y6', undefined, 'panel'); add('paper', 'فتحة الورق', 'PW', 'PH', 'PX', 'PY', undefined, 'printer'); return [...out.map(s => ({ ...s, ...p.overrides?.[s.id] })), ...p.custom]; }
export function globalShape(s: Shape, all: Shape[], seen = new Set<string>()): Shape { if (!s.parent)
    return s; if (seen.has(s.id))
    throw Error('دورة في علاقة العناصر'); seen.add(s.id); const parent = all.find(a => a.id === s.parent); if (!parent)
    return s; const g = globalShape(parent, all, seen); const a=g.rotation*Math.PI/180,dx=s.x+s.w/2-g.w/2,dy=s.y+s.h/2-g.h/2;return { ...s, x:g.x+g.w/2+dx*Math.cos(a)-dy*Math.sin(a)-s.w/2,y:g.y+g.h/2+dx*Math.sin(a)+dy*Math.cos(a)-s.h/2,rotation:s.rotation+g.rotation,parent:undefined };  }
export type Issue = {
    level: 'error' | 'warning';
    message: string;
};
export function validate(p: Project): Issue[] {
    const issues: Issue[] = [];
    const v = (c: string) => val(p, c);
    const W = v('W1'), H = v('H1');
    for (const [view, points] of Object.entries(p.profiles ?? {})) {
        if (points.length && !validPolygon(points))
            issues.push({ level: 'error', message: `${view}: حدود متقاطعة أو مضلع غير صالح.` });
    }
    const all = geometry(p);
    if (!W || !H)
        issues.push({ level: 'error', message: 'أدخل العرض والارتفاع الكليين لبدء الهندسة الفعلية.' });
    for (const m of p.measures)
        if (m.value !== null && (!Number.isFinite(m.value) || m.value < 0 || (/^[WHDB]/.test(m.code) && m.value === 0)))
            issues.push({ level: 'error', message: `${m.code}: البعد يجب أن يكون موجبًا.` });
    if (['W1', 'W3', 'M1', 'M2'].every(c => v(c) !== null)) {
        const d = v('W1')! - v('W3')! - v('M1')! - v('M2')!;
        if (Math.abs(d) > p.tolerance)
            issues.push({ level: 'error', message: `تعارض أفقي للشاشة: فرق ${d.toFixed(2)} mm بين عرض الجهاز ومجموع الشاشة والهامشين.` });
    }
    if (['M3', 'H3', 'M4', 'Y7'].every(c => v(c) !== null)) {
        const d = v('Y7')! - v('M3')! - v('H3')! - v('M4')!;
        if (Math.abs(d) > p.tolerance)
            issues.push({ level: 'error', message: `تعارض رأسي قبل لوحة المكونات: ${d.toFixed(2)} mm.` });
    }
    for (const s of all) {
        if (s.shape === 'path') {
            try {
                const paths = parsePath(s.path ?? '');
                if (!paths.length)
                    throw Error('مسار فارغ');
                if (s.zone === 'Cutout' && paths.some(a => !a.closed))
                    throw Error('مسار القص يجب أن يكون مغلقًا');
            }
            catch (e) {
                issues.push({ level: 'error', message: `${s.name}: ${String(e)}` });
            }
        }
        if (s.shape === 'circle' && s.w !== s.h)
            issues.push({ level: 'error', message: `${s.name}: الدائرة تتطلب عرضًا وارتفاعًا متساويين.` });
        if (s.shape === 'polygon' && (!s.points || s.points.length < 3))
            issues.push({ level: 'error', message: `${s.name}: المضلع يحتاج ثلاث نقاط على الأقل.` });
        const g = globalShape(s, all);
        const parent = all.find(a => a.id === s.parent);
        if (p.profiles?.front?.length >= 3 && !s.parent && s.zone === 'Cutout' && [[g.x, g.y], [g.x + g.w, g.y], [g.x, g.y + g.h], [g.x + g.w, g.y + g.h]].some(a => !inside(a, p.profiles.front)))
            issues.push({ level: 'error', message: `${s.name}: الفتحة خارج حدود قالب الأمام المقاس.` });
        if (parent && (s.x < 0 || s.y < 0 || s.x + s.w > parent.w + p.tolerance || s.y + s.h > parent.h + p.tolerance))
            issues.push({ level: 'error', message: `${s.name}: يتجاوز حدود العنصر الأب.` });
        if (W && H && !['back', 'left', 'right'].includes(s.parent ?? '') && (g.x < 0 || g.y < 0 || g.x + g.w > W + p.tolerance || g.y + g.h > H + p.tolerance))
            issues.push({ level: 'error', message: `${s.name}: خارج حدود الجهاز.` });
        if (s.r > Math.min(s.w, s.h) / 2)
            issues.push({ level: 'error', message: `${s.name}: نصف القطر أكبر من حدود الشكل.` });
    }
    if(p.mode!=='single')for(const piece of p.pieces){if(piece.shape==='polygon'&&piece.overlap)issues.push({level:'error',message:`${piece.name}: تراكب المضلع يجب إدخاله ضمن نقاط حدوده المقاسة؛ اجعل سماحية التراكب الإضافية صفرًا.`});
      if(piece.x<0||piece.y<0||(W&&piece.x+piece.w>Math.max(W,val(p,'W8')??0)+p.tolerance)||(H&&piece.y+piece.h>H+p.tolerance))issues.push({level:'error',message:`${piece.name}: حدود القطعة خارج الجهاز.`});
      for(const s of all.filter(s=>s.zone==='Cutout')){const g=globalShape(s,all),intersect=piece.x<g.x+g.w&&piece.x+piece.w>g.x&&piece.y<g.y+g.h&&piece.y+piece.h>g.y,contained=g.x>=piece.x&&g.y>=piece.y&&g.x+g.w<=piece.x+piece.w&&g.y+g.h<=piece.y+piece.h;
      if(intersect&&!contained)issues.push({level:'error',message:`${piece.name}: خط تقسيم القطعة يعبر فتحة ${s.name}؛ عدّل الحدود لتضم الفتحة كاملة.`});}
    }
    const openings = all.filter(s => ['screen', 'camera', 'printer', 'nfc', 'scanner'].includes(s.id));
    for (let i = 0; i < openings.length; i++)
        for (let j = i + 1; j < openings.length; j++) {
            const a = globalShape(openings[i], all), b = globalShape(openings[j], all);
            if (a.x < b.x + b.w - p.tolerance && a.x + a.w > b.x + p.tolerance && a.y < b.y + b.h - p.tolerance && a.y + a.h > b.y + p.tolerance)
                issues.push({ level: 'error', message: `تداخل بين ${a.name} و${b.name}.` });
        }
    if (!p.profiles?.front?.length)
        issues.push({ level: 'warning', message: 'حدود الأمام المسطحة غير مسجلة: مخطط الواجهة مرجعي فقط، ولا يُنشأ له مسار قص خارجي مفترض.' });
    const nonMeasured = p.measures.filter(m => m.value !== null && m.source !== 'measured');
    if (nonMeasured.length)
        issues.push({ level: 'warning', message: `${nonMeasured.length} قيمة مشتقة أو تقديرية تحتاج تحققًا ميدانيًا.` });
    if (['CS', 'CE', 'CH'].every(c => v(c) !== null) && Math.abs(v('CE')! - v('CS')! - v('CH')!) > p.tolerance)
        issues.push({ level: 'error', message: 'بداية الانحناء ونهايته لا تتفقان مع ارتفاعه الرأسي.' });
    if (v('CL') !== null && v('CH') !== null && v('CL')! + p.tolerance < v('CH')!)
        issues.push({ level: 'error', message: 'طول السطح الفعلي أقل من ارتفاعه الرأسي.' });
    const missing = p.measures.filter(m => m.value === null).length;
    if (missing)
        issues.push({ level: 'warning', message: `${missing} قياسًا لم يُسجّل بعد؛ التصدير يقتصر على العناصر المكتملة.` });
    if (!p.checks[1] || !v('CL'))
        issues.push({ level: 'warning', message: 'فرد الانحناء غير معتمد: يلزم طول سطح مقاس وقالب تتبع فعلي. لا يُستخدم الإسقاط الرأسي كقالب قص.' });
    issues.push({ level: 'warning', message: 'تحقق من قراءة NFC باستخدام مادة التغليف الفعلية قبل اعتماد تغطيته.' });
    return issues;
}
export const productionReady = (p: Project) => p.measures.every(m => m.value !== null && m.source === 'measured') && !validate(p).some(i => i.level === 'error') && Boolean(p.profiles?.front?.length) && (p.mode==='single'||(p.pieces.length>0&&p.pieces.every(s=>s.approved))) && p.checks.length >= 4 && p.checks.every(Boolean);
export function svgShape(s: Shape) { const common = `data-id="${escapeXml(s.id)}" transform="rotate(${s.rotation} ${s.x + s.w / 2} ${s.y + s.h / 2})"`; if (s.shape === 'circle' || s.shape === 'ellipse')
    return `<ellipse ${common} cx="${s.x + s.w / 2}" cy="${s.y + s.h / 2}" rx="${s.w / 2}" ry="${s.shape === 'circle' ? s.w / 2 : s.h / 2}"/>`; if (s.shape === 'polygon')
    return `<polygon ${common} points="${(s.points ?? []).map(a => `${s.x + a[0]},${s.y + a[1]}`).join(' ')}"/>`; if (s.shape === 'path')
    return `<g ${common}><path transform="translate(${s.x} ${s.y})" d="${escapeXml(s.path ?? '')}"/></g>`; return `<rect ${common} x="${s.x}" y="${s.y}" width="${s.w}" height="${s.h}" rx="${s.r}"/>`; }
export const escapeXml = (s: string) => s.replace(/[<>&"']/g, c => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;', '"': '&quot;', "'": '&apos;' }[c]!));
export function exportSvg(p: Project) { const W = val(p, 'W1'), H = val(p, 'H1'); if (!W || !H)
    throw Error('العرض والارتفاع مطلوبان'); const trace = p.profiles?.front ?? [], w = trace.length >= 3 ? Math.max(...trace.map(a => a[0])) : W, h = trace.length >= 3 ? Math.max(...trace.map(a => a[1])) : H; const all = geometry(p).filter(s=>!['back','left','right'].includes(s.parent??'')); const contour = trace.length >= 3 ? `<polygon points="${trace.map(a => a.join(',')).join(' ')}"/>` : `<rect width="${w}" height="${h}" rx="${val(p, 'RO') ?? 0}"/>`; return `<svg xmlns="http://www.w3.org/2000/svg" width="${w}mm" height="${h}mm" viewBox="0 0 ${w} ${h}"><title>${escapeXml(p.name)} — ${escapeXml(p.status)} — ${trace.length >= 3 ? 'MEASURED TRACE' : 'REFERENCE ONLY: NO FLAT TRACE'}</title><g id="${trace.length >= 3 ? 'CUT_CONTOURS' : 'DEVICE_OUTLINE_REFERENCE'}" fill="none" stroke="#00a890" stroke-width="0.25">${contour}</g><g id="COMPONENT_CUTOUTS" fill="none" stroke="#e24b71" stroke-width="0.25">${all.filter(s => s.zone === 'Cutout' && (!s.parent || all.some(a => a.id === s.parent))).map(s => svgShape(globalShape(s, all))).join('')}</g><g id="DEVICE_REFERENCE" fill="none" stroke="#64748b" stroke-width="0.2">${all.filter(s => s.zone !== 'Cutout').map(s => svgShape(globalShape(s, all))).join('')}</g><g id="WRAP_AREAS" fill="none" stroke="#00a890" stroke-width="0.25">${p.mode !== 'single' ? p.pieces.map(svgShape).join('') : ''}</g></svg>`; }
