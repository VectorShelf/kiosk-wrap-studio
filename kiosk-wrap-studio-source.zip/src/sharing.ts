import { z } from 'zod';

const MAX_LINK_LENGTH = 12000;
const MAX_PAYLOAD_BYTES = 1024 * 1024;
const snapshotSchema = z.object({
    version: z.literal(1),
    projectName: z.string().min(1).max(300),
    status: z.string().max(100),
    createdAt: z.string().datetime(),
    script: z.string().min(1).max(800000).startsWith('#target illustrator'),
    sha256: z.string().regex(/^[a-f0-9]{64}$/),
});
export type ScriptSnapshot = z.infer<typeof snapshotSchema>;

export async function scriptHash(script: string): Promise<string> {
    const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(script));
    return Array.from(new Uint8Array(digest), n => n.toString(16).padStart(2, '0')).join('');
}

function encodeBytes(bytes: Uint8Array): string {
    let binary = '';
    for (const byte of bytes) binary += String.fromCharCode(byte);
    return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

function decodeBytes(text: string): Uint8Array {
    if (!/^[A-Za-z0-9_-]+$/.test(text)) throw Error('رابط المشاركة غير صالح أو غير مكتمل.');
    try {
        return Uint8Array.from(atob(text.replace(/-/g, '+').replace(/_/g, '/')), c => c.charCodeAt(0));
    } catch {
        throw Error('رابط المشاركة غير صالح أو غير مكتمل.');
    }
}

export async function createScriptLink(
    script: string,
    projectName: string,
    status: string,
    baseUrl: string,
): Promise<string> {
    if (typeof CompressionStream === 'undefined') throw Error('حدّث المتصفح لإنشاء رابط مشاركة، أو نزّل ملف JSX مباشرة.');
    const snapshot = snapshotSchema.parse({
        version: 1, projectName, status, script,
        createdAt: new Date().toISOString(), sha256: await scriptHash(script),
    });
    const compressed = new Blob([JSON.stringify(snapshot)]).stream().pipeThrough(new CompressionStream('gzip'));
    const bytes = new Uint8Array(await new Response(compressed).arrayBuffer());
    const url = new URL(baseUrl);
    if (!['http:', 'https:'].includes(url.protocol)) throw Error('عنوان الموقع غير صالح.');
    url.search = '';
    url.hash = 'jsx=' + encodeBytes(bytes);
    if (url.href.length > MAX_LINK_LENGTH) throw Error('هذا السكريبت أكبر من حد رابط المشاركة. نزّل ملف JSX وشاركه كملف.');
    return url.href;
}

export async function readScriptLink(hash: string): Promise<ScriptSnapshot> {
    if (!hash.startsWith('#jsx=')) throw Error('رابط السكريبت غير صالح.');
    if (hash.length > MAX_LINK_LENGTH) throw Error('رابط المشاركة أكبر من الحد المسموح.');
    if (typeof DecompressionStream === 'undefined') throw Error('حدّث المتصفح لفتح رابط السكريبت.');
    const bytes = decodeBytes(hash.slice(5));
    const stream = new Blob([bytes as BlobPart]).stream().pipeThrough(new DecompressionStream('gzip'));
    const reader = stream.getReader();
    const chunks: Uint8Array[] = [];
    let size = 0;
    try {
        while (true) {
            const { value, done } = await reader.read();
            if (done) break;
            size += value.byteLength;
            if (size > MAX_PAYLOAD_BYTES) {
                await reader.cancel();
                throw Error('حجم بيانات رابط المشاركة أكبر من المسموح.');
            }
            chunks.push(value);
        }
    } catch (error) {
        if (error instanceof Error && error.message.includes('أكبر من المسموح')) throw error;
        throw Error('تعذر قراءة رابط المشاركة. أعد نسخ الرابط كاملًا من الجهاز المرسل.');
    } finally {
        reader.releaseLock();
    }
    const joined = new Uint8Array(size);
    let offset = 0;
    for (const chunk of chunks) { joined.set(chunk, offset); offset += chunk.byteLength; }
    let snapshot: ScriptSnapshot;
    try { snapshot = snapshotSchema.parse(JSON.parse(new TextDecoder().decode(joined))); }
    catch { throw Error('بيانات السكريبت غير صالحة. أنشئ رابط مشاركة جديدًا.'); }
    if (await scriptHash(snapshot.script) !== snapshot.sha256) throw Error('بصمة السكريبت غير متطابقة. أنشئ رابط مشاركة جديدًا.');
    return snapshot;
}

export function isLocalAddress(url: string): boolean {
    const host = new URL(url).hostname;
    return host === 'localhost' || host === '127.0.0.1' || host === '[::1]';
}
